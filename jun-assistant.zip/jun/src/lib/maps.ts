export type TravelMode = "DRIVE" | "TRANSIT" | "WALK" | "TWO_WHEELER";

export type Travel = { minutes: number; distanceKm: number; mode: TravelMode };

const cache = new Map<string, { at: number; value: Travel | null }>();
const TEN_MIN = 10 * 60 * 1000;

function key() {
  return process.env.GOOGLE_MAPS_API_KEY;
}

export function mapsConfigured() {
  return Boolean(key());
}

/** Traffic-aware travel time using the Google Routes API. Returns null when it can't be computed. */
export async function travelTime(
  origin: string,
  destination: string,
  mode: TravelMode = "DRIVE",
  departAt?: Date,
): Promise<Travel | null> {
  const apiKey = key();
  if (!apiKey || !origin || !destination) return null;

  const departure = departAt && departAt.getTime() > Date.now() + 60_000 ? departAt : undefined;
  const cacheKey = [origin, destination, mode, departure ? Math.round(departure.getTime() / TEN_MIN) : "now"].join("|");
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.at < TEN_MIN) return hit.value;

  const body: Record<string, unknown> = {
    origin: { address: origin },
    destination: { address: destination },
    travelMode: mode,
  };
  if (mode === "DRIVE" || mode === "TWO_WHEELER") body.routingPreference = "TRAFFIC_AWARE";
  if (departure) body.departureTime = departure.toISOString();

  let value: Travel | null = null;
  try {
    const res = await fetch("https://routes.googleapis.com/directions/v2:computeRoutes", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": apiKey,
        "X-Goog-FieldMask": "routes.duration,routes.distanceMeters",
      },
      body: JSON.stringify(body),
      cache: "no-store",
    });
    const data = await res.json();
    const route = data?.routes?.[0];
    if (res.ok && route?.duration) {
      value = {
        minutes: Math.max(1, Math.round(parseInt(String(route.duration), 10) / 60)),
        distanceKm: Math.round((route.distanceMeters ?? 0) / 100) / 10,
        mode,
      };
    } else if (!res.ok) {
      console.warn("Routes API:", data?.error?.message ?? res.status);
    }
  } catch (err) {
    console.warn("Routes API failed", err);
  }
  cache.set(cacheKey, { at: Date.now(), value });
  return value;
}

export type Place = {
  name: string;
  address: string;
  rating?: number;
  ratingCount?: number;
  priceLevel?: string;
  openNow?: boolean;
  mapsUrl?: string;
};

/** Text search with the Google Places API (New). */
export async function findPlaces(query: string, near?: string, max = 5): Promise<Place[]> {
  const apiKey = key();
  if (!apiKey) throw new Error("Add GOOGLE_MAPS_API_KEY to look up places.");
  const res = await fetch("https://places.googleapis.com/v1/places:searchText", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Goog-Api-Key": apiKey,
      "X-Goog-FieldMask":
        "places.displayName,places.formattedAddress,places.rating,places.userRatingCount,places.priceLevel,places.currentOpeningHours.openNow,places.googleMapsUri",
    },
    body: JSON.stringify({ textQuery: near ? `${query} near ${near}` : query, maxResultCount: max }),
    cache: "no-store",
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message ?? "Places lookup failed");
  type RawPlace = {
    displayName?: { text?: string };
    formattedAddress?: string;
    rating?: number;
    userRatingCount?: number;
    priceLevel?: string;
    currentOpeningHours?: { openNow?: boolean };
    googleMapsUri?: string;
  };
  return ((data.places ?? []) as RawPlace[]).map((p) => ({
    name: p.displayName?.text ?? "Unnamed place",
    address: p.formattedAddress ?? "",
    rating: p.rating,
    ratingCount: p.userRatingCount,
    priceLevel: p.priceLevel?.replace("PRICE_LEVEL_", "").toLowerCase(),
    openNow: p.currentOpeningHours?.openNow,
    mapsUrl: p.googleMapsUri,
  }));
}

export function directionsUrl(origin: string | undefined, destination: string, mode: TravelMode = "DRIVE") {
  const travelmode = { DRIVE: "driving", TRANSIT: "transit", WALK: "walking", TWO_WHEELER: "driving" }[mode];
  const p = new URLSearchParams({ api: "1", destination, travelmode });
  if (origin) p.set("origin", origin);
  return `https://www.google.com/maps/dir/?${p}`;
}
