import Anthropic from "@anthropic-ai/sdk";
import { JUN_PERSONA, toneHint } from "./persona";
import {
  createBlock,
  createDraftReply,
  freeBusy,
  getEvent,
  listEvents,
  listInbox,
  makeOnline,
  moveEvent,
} from "./google";
import { findPlaces, travelTime } from "./maps";
import { enrich, findSlots, fmtDateTime, fmtTime, localMidnight, type Prefs } from "./schedule";

export type ChatTurn = { role: "user" | "assistant"; content: string };

const tools: Anthropic.Tool[] = [
  {
    name: "get_schedule",
    description:
      "Get calendar events between two dates (inclusive), with Jun's travel advice for in-person meetings (travel minutes, leave-by time, verdict: in_person, consider_online, take_online, online).",
    input_schema: {
      type: "object",
      properties: {
        from_date: { type: "string", description: "YYYY-MM-DD in the user's time zone" },
        to_date: { type: "string", description: "YYYY-MM-DD in the user's time zone" },
      },
      required: ["from_date", "to_date"],
    },
  },
  {
    name: "find_free_slots",
    description: "Find open working-hour slots. Pass event_id to find times that also suit that meeting's attendees.",
    input_schema: {
      type: "object",
      properties: {
        duration_minutes: { type: "integer" },
        event_id: { type: "string" },
        days_ahead: { type: "integer", description: "How many days to search, default 7" },
        from_date: { type: "string", description: "Optional YYYY-MM-DD to start searching from" },
      },
      required: ["duration_minutes"],
    },
  },
  {
    name: "move_meeting",
    description:
      "Move a meeting to a new start time, keeping its length. Attendees get an updated invite. Requires confirmed=true, which you may only set after the user explicitly agreed.",
    input_schema: {
      type: "object",
      properties: {
        event_id: { type: "string" },
        new_start: { type: "string", description: "ISO 8601 with offset, e.g. 2026-11-04T15:00:00+08:00" },
        confirmed: { type: "boolean" },
      },
      required: ["event_id", "new_start", "confirmed"],
    },
  },
  {
    name: "make_meeting_online",
    description:
      "Switch a meeting to Google Meet (adds a Meet link, clears the physical location, notifies attendees). Requires confirmed=true after explicit user agreement.",
    input_schema: {
      type: "object",
      properties: { event_id: { type: "string" }, confirmed: { type: "boolean" } },
      required: ["event_id", "confirmed"],
    },
  },
  {
    name: "block_dates",
    description:
      "Mark whole days as unavailable so nobody can book meetings. Dates inclusive. Requires confirmed=true after explicit user agreement.",
    input_schema: {
      type: "object",
      properties: {
        start_date: { type: "string", description: "YYYY-MM-DD" },
        end_date: { type: "string", description: "YYYY-MM-DD, same as start for a single day" },
        reason: { type: "string", description: "Short label, e.g. Out of office" },
        confirmed: { type: "boolean" },
      },
      required: ["start_date", "end_date", "reason", "confirmed"],
    },
  },
  {
    name: "check_travel",
    description: "Traffic-aware travel time between two places via Google Maps.",
    input_schema: {
      type: "object",
      properties: {
        destination: { type: "string" },
        origin: { type: "string", description: "Defaults to the user's home base" },
        depart_at: { type: "string", description: "Optional ISO time of departure" },
        mode: { type: "string", enum: ["DRIVE", "TRANSIT", "WALK", "TWO_WHEELER"] },
      },
      required: ["destination"],
    },
  },
  {
    name: "find_places",
    description: "Search Google Maps for restaurants, cafés, hotels or any place, optionally near an address.",
    input_schema: {
      type: "object",
      properties: {
        query: { type: "string", description: "e.g. quiet Japanese restaurant for a business lunch" },
        near: { type: "string", description: "Address or area" },
      },
      required: ["query"],
    },
  },
  {
    name: "get_inbox",
    description: "Recent inbox emails from the last 7 days (sender, subject, snippet, id).",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "draft_email_reply",
    description: "Save a reply as a Gmail draft (does not send). Write the full reply body in the user's voice.",
    input_schema: {
      type: "object",
      properties: { message_id: { type: "string" }, body: { type: "string" } },
      required: ["message_id", "body"],
    },
  },
];

type Ctx = { token: string; tz: string; prefs: Prefs; changed: boolean };

async function runTool(name: string, input: Record<string, unknown>, ctx: Ctx): Promise<unknown> {
  const { token, tz, prefs } = ctx;
  const needsYes = (what: string) => ({
    status: "needs_confirmation",
    message: `Not done yet. Ask the user to confirm: ${what}`,
  });

  switch (name) {
    case "get_schedule": {
      const from = localMidnight(String(input.from_date), tz);
      const to = new Date(localMidnight(String(input.to_date), tz).getTime() + 86400000);
      const events = await enrich(await listEvents(token, from, to), prefs, tz);
      return events.map((e) => ({
        id: e.id,
        title: e.title,
        when: e.allDay ? "all day" : `${fmtDateTime(e.start, tz)} to ${fmtTime(e.end, tz)}`,
        location: e.location,
        online: e.online,
        blocked_by_jun: e.isBlock,
        attendees: e.attendees,
        travel: e.advice,
      }));
    }
    case "find_free_slots": {
      const days = Number(input.days_ahead ?? 7);
      const from = input.from_date ? localMidnight(String(input.from_date), tz).getTime() : Date.now();
      let emails: string[] = [];
      if (input.event_id) {
        const ev = await getEvent(token, String(input.event_id));
        emails = (ev.attendees ?? []).filter((a) => !a.self).map((a) => a.email);
      }
      const busy = await freeBusy(token, new Date(from), new Date(from + days * 86400000), emails);
      return findSlots(busy, Number(input.duration_minutes), tz, { from, days });
    }
    case "move_meeting": {
      const ev = await getEvent(token, String(input.event_id));
      const start = new Date(String(input.new_start));
      if (Number.isNaN(start.getTime())) return { error: "new_start is not a valid date" };
      const length = Date.parse(ev.end.dateTime ?? "") - Date.parse(ev.start.dateTime ?? "");
      if (!input.confirmed) return needsYes(`move "${ev.summary}" to ${fmtDateTime(start, tz)}`);
      await moveEvent(token, ev.id, start, new Date(start.getTime() + (length || 30 * 60000)));
      ctx.changed = true;
      return { status: "moved", title: ev.summary, new_time: fmtDateTime(start, tz) };
    }
    case "make_meeting_online": {
      const ev = await getEvent(token, String(input.event_id));
      if (!input.confirmed) return needsYes(`switch "${ev.summary}" to Google Meet and notify attendees`);
      const updated = await makeOnline(token, ev.id);
      ctx.changed = true;
      return { status: "online", title: ev.summary, meet_link: updated.hangoutLink };
    }
    case "block_dates": {
      if (!input.confirmed) return needsYes(`block ${input.start_date} to ${input.end_date} as "${input.reason}"`);
      await createBlock(token, String(input.start_date), String(input.end_date), String(input.reason ?? ""));
      ctx.changed = true;
      return { status: "blocked", from: input.start_date, to: input.end_date };
    }
    case "check_travel": {
      const origin = String(input.origin ?? prefs.homeBase ?? "");
      if (!origin) return { error: "No origin. Ask the user for their starting point or to set a home base in Settings." };
      const mode = (input.mode as Prefs["mode"]) ?? prefs.mode;
      const depart = input.depart_at ? new Date(String(input.depart_at)) : undefined;
      const t = await travelTime(origin, String(input.destination), mode, depart);
      return t ?? { error: "Google Maps couldn't calculate that route." };
    }
    case "find_places":
      return findPlaces(String(input.query), input.near ? String(input.near) : prefs.homeBase);
    case "get_inbox":
      return (await listInbox(token, 12)).map(({ id, from, subject, snippet, date, unread }) => ({
        id,
        from,
        subject,
        snippet,
        date,
        unread,
      }));
    case "draft_email_reply": {
      const d = await createDraftReply(token, String(input.message_id), String(input.body));
      return { status: "draft_saved", draft_id: d.id };
    }
    default:
      return { error: `Unknown tool ${name}` };
  }
}

export async function askJun(opts: {
  token: string;
  tz: string;
  prefs: Prefs;
  history: ChatTurn[];
  userName?: string;
}): Promise<{ reply: string; changed: boolean }> {
  if (!process.env.ANTHROPIC_API_KEY) {
    return {
      reply: "My brain isn't plugged in yet. Add ANTHROPIC_API_KEY in your Vercel settings and I'll be right with you.",
      changed: false,
    };
  }
  const client = new Anthropic();
  const model = process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";
  const now = new Date();
  const last = opts.history.filter((h) => h.role === "user").at(-1)?.content ?? "";

  const system = `${JUN_PERSONA}

Context
- User: ${opts.userName ?? "your boss"}
- Right now: ${fmtDateTime(now, opts.tz)} (${opts.tz}), ISO ${now.toISOString()}
- Home base: ${opts.prefs.homeBase ?? "not set"}
- Default travel mode: ${opts.prefs.mode}; preferred buffer before meetings: ${opts.prefs.bufferMinutes} min
- Tone of the latest message: ${toneHint(last)}`;

  const messages: Anthropic.MessageParam[] = opts.history.slice(-16).map((t) => ({ role: t.role, content: t.content }));
  while (messages.length && messages[0].role !== "user") messages.shift();

  const ctx: Ctx = { token: opts.token, tz: opts.tz, prefs: opts.prefs, changed: false };

  for (let step = 0; step < 8; step++) {
    const res = await client.messages.create({ model, max_tokens: 1024, system, tools, messages });

    if (res.stop_reason !== "tool_use") {
      const reply = res.content
        .filter((b): b is Anthropic.TextBlock => b.type === "text")
        .map((b) => b.text)
        .join("\n")
        .trim();
      return { reply: reply || "Done.", changed: ctx.changed };
    }

    messages.push({ role: "assistant", content: res.content });
    const results: Anthropic.ToolResultBlockParam[] = await Promise.all(
      res.content
        .filter((b): b is Anthropic.ToolUseBlock => b.type === "tool_use")
        .map(async (b) => {
          try {
            const out = await runTool(b.name, b.input as Record<string, unknown>, ctx);
            return { type: "tool_result" as const, tool_use_id: b.id, content: JSON.stringify(out) };
          } catch (err) {
            return {
              type: "tool_result" as const,
              tool_use_id: b.id,
              content: err instanceof Error ? err.message : "Tool failed",
              is_error: true,
            };
          }
        }),
    );
    messages.push({ role: "user", content: results });
  }
  return { reply: "That took more steps than I expected. Can you narrow it down for me?", changed: ctx.changed };
}
