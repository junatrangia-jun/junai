import { advise, isOnline, meetingLink, physicalLocation, type Advice } from "./advisor";
import type { CalEvent } from "./google";
import { directionsUrl, travelTime, type TravelMode } from "./maps";

export type Prefs = { homeBase?: string; bufferMinutes: number; mode: TravelMode };

export type DayEvent = {
  id: string;
  title: string;
  start: string;
  end: string;
  allDay: boolean;
  location: string | null;
  meetLink?: string;
  online: boolean;
  attendees: number;
  organizerSelf: boolean;
  htmlLink?: string;
  isBlock: boolean;
  advice: Advice | null;
  directionsUrl?: string;
};

export function readPrefs(params: URLSearchParams | Record<string, unknown>): Prefs {
  const get = (k: string) =>
    params instanceof URLSearchParams ? params.get(k) ?? undefined : (params[k] as string | undefined);
  const mode = (get("mode") ?? "DRIVE").toUpperCase();
  return {
    homeBase: get("origin")?.toString().trim() || undefined,
    bufferMinutes: Math.min(60, Math.max(0, Number(get("buffer") ?? 10) || 10)),
    mode: (["DRIVE", "TRANSIT", "WALK", "TWO_WHEELER"].includes(mode) ? mode : "DRIVE") as TravelMode,
  };
}

const ms = (s: { dateTime?: string; date?: string }) =>
  s.dateTime ? Date.parse(s.dateTime) : Date.parse(`${s.date}T00:00:00`);

export function localParts(date: Date | number, tz: string) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    weekday: "short",
    hourCycle: "h23",
  }).formatToParts(new Date(date));
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return {
    ymd: `${get("year")}-${get("month")}-${get("day")}`,
    hour: Number(get("hour")),
    minute: Number(get("minute")),
    weekday: get("weekday"),
  };
}

export function fmtTime(date: Date | number | string, tz: string) {
  return new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "2-digit" }).format(new Date(date));
}

export function fmtDateTime(date: Date | number | string, tz: string) {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(date));
}

/** Converts calendar events into Jun's view: online or in person, travel time, leave-by, and a verdict. */
export async function enrich(events: CalEvent[], prefs: Prefs, tz: string): Promise<DayEvent[]> {
  const now = Date.now();
  const horizon = now + 3 * 86400000;
  const sorted = [...events].sort((a, b) => ms(a.start) - ms(b.start));

  // Pass 1: decide each meeting's origin (previous in-person meeting that day, else home base).
  const plans = sorted.map((e, i) => {
    const allDay = !e.start.dateTime;
    const start = ms(e.start);
    const end = ms(e.end);
    const loc = physicalLocation(e);
    let prevEnd: number | undefined;
    let prevLoc: string | null = null;
    if (!allDay) {
      const day = localParts(start, tz).ymd;
      for (let j = i - 1; j >= 0; j--) {
        const p = sorted[j];
        if (!p.start.dateTime) continue;
        const pEnd = ms(p.end);
        if (localParts(ms(p.start), tz).ymd !== day || pEnd > start) continue;
        prevEnd = prevEnd === undefined ? pEnd : Math.max(prevEnd, pEnd);
        if (!prevLoc) prevLoc = physicalLocation(p);
      }
    }
    return { e, allDay, start, end, loc, prevEnd, origin: prevLoc ?? prefs.homeBase };
  });

  // Pass 2: fetch travel times in parallel and apply the advisor.
  return Promise.all(
    plans.map(async ({ e, allDay, start, end, loc, prevEnd, origin }): Promise<DayEvent> => {
      const isBlock = e.extendedProperties?.private?.jun === "block";
      const online = isOnline(e);
      let advice: Advice | null = null;

      if (!allDay && !isBlock) {
        if (online) {
          advice = { verdict: "online", reason: "Video call. No travel needed." };
        } else if (!loc) {
          advice = { verdict: "no_location", reason: "No location on this one, so I can't plan the trip." };
        } else if (end > now && start < horizon) {
          if (!origin) {
            advice = { verdict: "no_location", reason: "Set your home base in Settings so I can time the trip." };
          } else {
            const travel = await travelTime(origin, loc, prefs.mode, new Date(start - 60 * 60000));
            if (!travel) {
              advice = { verdict: "no_location", reason: "Google Maps couldn't route this address.", origin };
            } else {
              const freeFrom = Math.max(prevEnd ?? now, now);
              const gapMinutes = start > now ? (start - freeFrom) / 60000 : 0;
              const v = advise({
                meetingMinutes: Math.max(15, Math.round((end - start) / 60000)),
                travelMinutes: travel.minutes,
                gapMinutes: start > now ? gapMinutes : Infinity,
                bufferMinutes: prefs.bufferMinutes,
              });
              advice = {
                ...v,
                travelMinutes: travel.minutes,
                distanceKm: travel.distanceKm,
                leaveBy: new Date(start - (travel.minutes + prefs.bufferMinutes) * 60000).toISOString(),
                origin,
              };
            }
          }
        }
      }

      return {
        id: e.id,
        title: e.summary?.trim() || "(untitled)",
        start: new Date(start).toISOString(),
        end: new Date(end).toISOString(),
        allDay,
        location: loc,
        meetLink: meetingLink(e),
        online,
        attendees: e.attendees?.filter((a) => !a.self).length ?? 0,
        organizerSelf: e.organizer?.self ?? true,
        htmlLink: e.htmlLink,
        isBlock,
        advice,
        directionsUrl: loc ? directionsUrl(origin, loc, prefs.mode) : undefined,
      };
    }),
  );
}

/** Jun's morning-style summary, in her voice. Rule-based so it loads instantly. */
export function brief(events: DayEvent[], tz: string, name?: string): string {
  const now = Date.now();
  const today = localParts(now, tz).ymd;
  const hour = localParts(now, tz).hour;
  const hello = hour < 12 ? "Morning" : hour < 18 ? "Afternoon" : "Evening";
  const who = name ? `, ${name.split(" ")[0]}` : "";

  const blockedToday = events.some((e) => e.isBlock && localParts(Date.parse(e.start), tz).ymd <= today && Date.parse(e.end) > now);
  const left = events.filter(
    (e) => !e.allDay && !e.isBlock && localParts(Date.parse(e.start), tz).ymd === today && Date.parse(e.end) > now,
  );

  if (left.length === 0) {
    return blockedToday
      ? `${hello}${who}. You're marked unavailable today and I'm keeping it that way.`
      : `${hello}${who}. Nothing left on the calendar today. Guard that time, or tell me what to fill it with.`;
  }

  const parts = [
    `${hello}${who}. ${left.length === 1 ? "One meeting" : `${left.length} meetings`} left today, starting with ${left[0].title} at ${fmtTime(left[0].start, tz)}.`,
  ];
  const online = left.find((e) => e.advice?.verdict === "take_online");
  if (online) parts.push(`${online === left[0] ? "I'd take that one online." : `I'd take ${online.title} online.`} ${online.advice?.reason}`);
  const trip = left.find((e) => e.advice?.leaveBy && e.advice.verdict !== "take_online" && Date.parse(e.advice.leaveBy) > now);
  if (trip?.advice?.leaveBy) parts.push(`For ${trip.title}, leave by ${fmtTime(trip.advice.leaveBy, tz)}.`);
  if (!online && !trip) parts.push("No travel today. Keep your cameras charged.");
  return parts.join(" ");
}

/** Finds open working-hour slots (Mon–Fri, 9am–6pm local) that avoid every busy interval. */
export function findSlots(
  busy: { start: number; end: number }[],
  durationMinutes: number,
  tz: string,
  opts: { from?: number; days?: number; startHour?: number; endHour?: number; max?: number } = {},
) {
  const { days = 7, startHour = 9, endHour = 18, max = 5 } = opts;
  const step = 30 * 60000;
  const dur = durationMinutes * 60000;
  let t = Math.ceil(Math.max(opts.from ?? 0, Date.now() + 15 * 60000) / step) * step;
  const stop = t + days * 86400000;
  const out: { start: string; end: string; label: string }[] = [];
  const perDay = new Map<string, number>();

  while (t < stop && out.length < max) {
    const p = localParts(t, tz);
    const endP = localParts(t + dur, tz);
    const weekday = !["Sat", "Sun"].includes(p.weekday);
    const inHours =
      p.hour >= startHour && (endP.hour < endHour || (endP.hour === endHour && endP.minute === 0)) && endP.ymd === p.ymd;
    const free = !busy.some((b) => t < b.end && t + dur > b.start);
    if (weekday && inHours && free && (perDay.get(p.ymd) ?? 0) < 2) {
      out.push({ start: new Date(t).toISOString(), end: new Date(t + dur).toISOString(), label: fmtDateTime(t, tz) });
      perDay.set(p.ymd, (perDay.get(p.ymd) ?? 0) + 1);
      t += 2 * 60 * 60000; // spread suggestions out
      continue;
    }
    t += step;
  }
  return out;
}

function tzOffsetMs(date: Date, tz: string) {
  const p = new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).formatToParts(date);
  const n = (t: string) => Number(p.find((x) => x.type === t)?.value ?? 0);
  return Date.UTC(n("year"), n("month") - 1, n("day"), n("hour"), n("minute"), n("second")) - date.getTime();
}

/** UTC instant of local midnight for a YYYY-MM-DD date in a time zone. */
export function localMidnight(ymd: string, tz: string): Date {
  const guess = new Date(`${ymd}T00:00:00Z`);
  return new Date(guess.getTime() - tzOffsetMs(guess, tz));
}
