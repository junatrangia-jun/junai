import { NextRequest, NextResponse } from "next/server";
import { createBlock, deleteEvent, listBlocks } from "@/lib/google";
import { fail, googleToken, HttpError } from "@/lib/http";

export const dynamic = "force-dynamic";

function shape(e: Awaited<ReturnType<typeof listBlocks>>[number]) {
  const end = new Date(`${e.end.date}T00:00:00Z`);
  end.setUTCDate(end.getUTCDate() - 1);
  return {
    id: e.id,
    reason: (e.summary ?? "Unavailable").replace(/^Unavailable:\s*/, ""),
    startDate: e.start.date ?? e.start.dateTime?.slice(0, 10),
    endDate: e.end.date ? end.toISOString().slice(0, 10) : e.end.dateTime?.slice(0, 10),
  };
}

export async function GET(req: NextRequest) {
  try {
    const token = await googleToken(req);
    return NextResponse.json({ blocks: (await listBlocks(token)).map(shape) });
  } catch (err) {
    return fail(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const token = await googleToken(req);
    const { startDate, endDate, reason } = await req.json();
    const created = await createBlock(token, String(startDate), String(endDate || startDate), String(reason ?? ""));
    return NextResponse.json({ block: shape(created) }, { status: 201 });
  } catch (err) {
    return fail(err);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const token = await googleToken(req);
    const id = req.nextUrl.searchParams.get("id");
    if (!id) throw new HttpError("Missing id.", 400);
    await deleteEvent(token, id);
    return NextResponse.json({ ok: true });
  } catch (err) {
    return fail(err);
  }
}
