import { NextRequest, NextResponse } from "next/server";
import { getEvent, makeOnline, moveEvent } from "@/lib/google";
import { fail, googleToken, HttpError } from "@/lib/http";

export const dynamic = "force-dynamic";

/** PATCH { action: "move", start: ISO } | { action: "online" } */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const token = await googleToken(req);
    const body = await req.json();

    if (body.action === "online") {
      const ev = await makeOnline(token, id);
      return NextResponse.json({ ok: true, meetLink: ev.hangoutLink });
    }

    if (body.action === "move") {
      const ev = await getEvent(token, id);
      const start = new Date(String(body.start));
      if (Number.isNaN(start.getTime())) throw new HttpError("Pick a valid new time.", 400);
      const length = Date.parse(ev.end.dateTime ?? "") - Date.parse(ev.start.dateTime ?? "");
      await moveEvent(token, id, start, new Date(start.getTime() + (length || 30 * 60000)));
      return NextResponse.json({ ok: true });
    }

    throw new HttpError("Unknown action.", 400);
  } catch (err) {
    return fail(err);
  }
}
