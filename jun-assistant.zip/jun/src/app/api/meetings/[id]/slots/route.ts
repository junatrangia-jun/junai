import { NextRequest, NextResponse } from "next/server";
import { freeBusy, getEvent, getTimeZone } from "@/lib/google";
import { fail, googleToken } from "@/lib/http";
import { findSlots } from "@/lib/schedule";

export const dynamic = "force-dynamic";

/** Suggests new times for a meeting that suit you and (where visible) the other attendees. */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const token = await googleToken(req);
    const [ev, tz] = await Promise.all([getEvent(token, id), getTimeZone(token)]);
    const minutes = Math.max(
      15,
      Math.round((Date.parse(ev.end.dateTime ?? "") - Date.parse(ev.start.dateTime ?? "")) / 60000) || 30,
    );
    const emails = (ev.attendees ?? []).filter((a) => !a.self).map((a) => a.email);
    const now = Date.now();
    const busy = await freeBusy(token, new Date(now), new Date(now + 7 * 86400000), emails);
    // The meeting itself shouldn't block its own new slot.
    const own = { start: Date.parse(ev.start.dateTime ?? ""), end: Date.parse(ev.end.dateTime ?? "") };
    const others = busy.filter((b) => !(b.start === own.start && b.end === own.end));
    return NextResponse.json({ timeZone: tz, minutes, slots: findSlots(others, minutes, tz) });
  } catch (err) {
    return fail(err);
  }
}
