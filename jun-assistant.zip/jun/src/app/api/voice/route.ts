import { NextRequest, NextResponse } from "next/server";
import { fail, googleToken, HttpError } from "@/lib/http";

export const dynamic = "force-dynamic";

/** GET tells the app whether a premium voice is configured. */
export async function GET() {
  return NextResponse.json({ premium: Boolean(process.env.ELEVENLABS_API_KEY && process.env.ELEVENLABS_VOICE_ID) });
}

/** POST { text } → audio/mpeg in Jun's ElevenLabs voice. */
export async function POST(req: NextRequest) {
  try {
    await googleToken(req);
    const key = process.env.ELEVENLABS_API_KEY;
    const voice = process.env.ELEVENLABS_VOICE_ID;
    if (!key || !voice) throw new HttpError("No premium voice configured.", 404);
    const { text } = await req.json();
    const clean = String(text ?? "").slice(0, 1500);
    if (!clean.trim()) throw new HttpError("Nothing to say.", 400);

    const res = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voice)}?output_format=mp3_44100_128`,
      {
        method: "POST",
        headers: { "xi-api-key": key, "Content-Type": "application/json", Accept: "audio/mpeg" },
        body: JSON.stringify({
          text: clean,
          model_id: process.env.ELEVENLABS_MODEL || "eleven_multilingual_v2",
          // Lower stability = more expressive; style adds a bit of playfulness.
          voice_settings: { stability: 0.42, similarity_boost: 0.8, style: 0.35, use_speaker_boost: true },
        }),
      },
    );
    if (!res.ok) throw new HttpError(`Voice service error (${res.status}).`, 502);
    return new NextResponse(res.body, { headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" } });
  } catch (err) {
    return fail(err);
  }
}
