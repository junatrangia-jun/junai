import { NextRequest, NextResponse } from "next/server";
import { fail, googleToken, HttpError } from "@/lib/http";
import { findPlaces } from "@/lib/maps";

export async function GET(req: NextRequest) {
  try {
    await googleToken(req); // signed-in users only, so your Maps key isn't public
    const q = req.nextUrl.searchParams.get("q");
    if (!q) throw new HttpError("What are you looking for?", 400);
    const near = req.nextUrl.searchParams.get("near") ?? undefined;
    return NextResponse.json({ places: await findPlaces(q, near) });
  } catch (err) {
    return fail(err);
  }
}
