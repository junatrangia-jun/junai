import { NextRequest, NextResponse } from "next/server";
import { createDraftReply } from "@/lib/google";
import { fail, googleToken, HttpError } from "@/lib/http";

export async function POST(req: NextRequest) {
  try {
    const token = await googleToken(req);
    const { messageId, body } = await req.json();
    if (!messageId || !String(body ?? "").trim()) throw new HttpError("Write a reply before saving.", 400);
    const draft = await createDraftReply(token, String(messageId), String(body));
    return NextResponse.json({ ok: true, draftId: draft.id });
  } catch (err) {
    return fail(err);
  }
}
