"use client";

import { useEffect, useState } from "react";
import { signOut } from "next-auth/react";
import type { Settings } from "@/lib/client";
import { useApp } from "./AppContext";
import { Dialog } from "./Dialog";

export function SettingsDialog() {
  const { settings, setSettings, settingsOpen, setSettingsOpen, voice, notify } = useApp();
  const [draft, setDraft] = useState<Settings>(settings);
  const [permission, setPermission] = useState<string>("default");

  useEffect(() => {
    if (settingsOpen) setDraft(settings);
    if ("Notification" in window) setPermission(Notification.permission);
  }, [settingsOpen, settings]);

  const set = <K extends keyof Settings>(k: K, v: Settings[K]) => setDraft((d) => ({ ...d, [k]: v }));

  return (
    <Dialog open={settingsOpen} onClose={() => setSettingsOpen(false)} title="Settings" wide>
      <form
        className="settings"
        onSubmit={(e) => {
          e.preventDefault();
          setSettings(draft);
          setSettingsOpen(false);
          notify({ tone: "jade", title: "Settings saved" });
        }}
      >
        <fieldset>
          <legend>Travel</legend>
          <label className="field">
            <span>Home base</span>
            <input
              className="input"
              value={draft.homeBase}
              onChange={(e) => set("homeBase", e.target.value)}
              placeholder="Office or home address"
              autoComplete="street-address"
              autoFocus
            />
            <small>Where your day usually starts. Jun times trips from here or from your previous meeting.</small>
          </label>
          <div className="field-row">
            <label className="field">
              <span>How you get around</span>
              <select className="input" value={draft.mode} onChange={(e) => set("mode", e.target.value as Settings["mode"])}>
                <option value="DRIVE">Car</option>
                <option value="TWO_WHEELER">Motorbike</option>
                <option value="TRANSIT">Public transport</option>
                <option value="WALK">Walking</option>
              </select>
            </label>
            <label className="field">
              <span>Arrive early by</span>
              <select className="input" value={draft.bufferMinutes} onChange={(e) => set("bufferMinutes", Number(e.target.value))}>
                {[0, 5, 10, 15, 20, 30].map((m) => (
                  <option key={m} value={m}>
                    {m} min
                  </option>
                ))}
              </select>
            </label>
          </div>
        </fieldset>

        <fieldset>
          <legend>Alerts</legend>
          <label className="field">
            <span>Warn me</span>
            <select className="input" value={draft.alertMinutes} onChange={(e) => set("alertMinutes", Number(e.target.value))}>
              {[5, 10, 15, 20, 30].map((m) => (
                <option key={m} value={m}>
                  {m} min before I need to leave or join
                </option>
              ))}
            </select>
          </label>
          <div className="field">
            <span>Desktop alerts</span>
            {permission === "granted" ? (
              <small>On. Jun can alert you even when this tab is in the background.</small>
            ) : permission === "denied" ? (
              <small>Blocked in your browser settings. Allow notifications for this site to turn them on.</small>
            ) : (
              <button
                type="button"
                className="btn"
                onClick={async () => setPermission(await Notification.requestPermission())}
              >
                Turn on desktop alerts
              </button>
            )}
          </div>
        </fieldset>

        <fieldset>
          <legend>Voice</legend>
          <label className="check">
            <input type="checkbox" checked={draft.speakReplies} onChange={(e) => set("speakReplies", e.target.checked)} />
            <span>Jun speaks her replies and alerts</span>
          </label>
          <label className="field">
            <span>I'll talk to Jun in</span>
            <select className="input" value={draft.voiceLang} onChange={(e) => set("voiceLang", e.target.value)}>
              <option value="en-US">English (US)</option>
              <option value="en-GB">English (UK)</option>
              <option value="en-PH">English (Philippines)</option>
              <option value="fil-PH">Filipino</option>
              <option value="en-AU">English (Australia)</option>
            </select>
          </label>
          <small className="muted">
            {voice.premium ? "Using Jun's custom voice." : "Using your browser's voice. Add an ElevenLabs voice for Jun's own sound."}
            {!voice.canListen && " Voice input isn't supported in this browser; Chrome, Edge and Safari support it."}
          </small>
        </fieldset>

        <div className="dialog__actions dialog__actions--split">
          <button type="button" className="btn btn--quiet" onClick={() => signOut({ callbackUrl: "/" })}>
            Sign out
          </button>
          <div>
            <button type="button" className="btn btn--quiet" onClick={() => setSettingsOpen(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn--primary">
              Save settings
            </button>
          </div>
        </div>
      </form>
    </Dialog>
  );
}
