"use client";

import { useEffect, useState } from "react";
import { api, fmtDay, fmtTime } from "@/lib/client";
import { useApp } from "./AppContext";
import { Dialog } from "./Dialog";

type Slot = { start: string; end: string; label: string };

function toLocalInput(iso: string) {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function MoveDialog() {
  const { moving, setMoving, refresh, notify, schedule } = useApp();
  const [slots, setSlots] = useState<Slot[] | null>(null);
  const [choice, setChoice] = useState<string>("");
  const [custom, setCustom] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const tz = schedule.timeZone;

  useEffect(() => {
    if (!moving) return;
    setSlots(null);
    setChoice("");
    setCustom(toLocalInput(moving.start));
    setError(null);
    api<{ slots: Slot[] }>(`/api/meetings/${encodeURIComponent(moving.id)}/slots`)
      .then((d) => {
        setSlots(d.slots);
        if (d.slots[0]) setChoice(d.slots[0].start);
      })
      .catch((e) => {
        setSlots([]);
        setError(e.message);
      });
  }, [moving]);

  const close = () => setMoving(null);

  async function submit() {
    if (!moving) return;
    const start = choice === "custom" ? new Date(custom).toISOString() : choice;
    if (!start || Number.isNaN(Date.parse(start))) {
      setError("Pick one of Jun's times or choose your own.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await api(`/api/meetings/${encodeURIComponent(moving.id)}`, {
        method: "PATCH",
        body: JSON.stringify({ action: "move", start }),
      });
      notify({ tone: "jade", title: `Moved ${moving.title}`, body: `Now ${fmtDay(start, tz)}, ${fmtTime(start, tz)}. Attendees were notified.` });
      close();
      refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't move the meeting.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={Boolean(moving)} onClose={close} title={moving ? `Move ${moving.title}` : "Move meeting"}>
      {moving && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          <p className="dialog__body">
            Currently {fmtDay(moving.start, tz)} at {fmtTime(moving.start, tz)}.{" "}
            {moving.attendees > 0 ? "Everyone invited gets an updated invite." : "It's just you on this one."}
          </p>
          <fieldset className="slots">
            <legend>Times that work</legend>
            {slots === null && <p className="muted">Checking calendars…</p>}
            {slots?.length === 0 && !error && <p className="muted">No open slots in the next week. Pick your own below.</p>}
            {slots?.map((s, i) => (
              <label key={s.start} className="slot">
                <input
                  type="radio"
                  name="slot"
                  value={s.start}
                  checked={choice === s.start}
                  onChange={() => setChoice(s.start)}
                  autoFocus={i === 0}
                />
                <span>{s.label}</span>
              </label>
            ))}
            <label className="slot">
              <input type="radio" name="slot" value="custom" checked={choice === "custom"} onChange={() => setChoice("custom")} />
              <span>Another time</span>
            </label>
            {choice === "custom" && (
              <input
                className="input"
                type="datetime-local"
                aria-label="New start time"
                value={custom}
                onChange={(e) => setCustom(e.target.value)}
                required
              />
            )}
          </fieldset>
          {error && (
            <p className="form-error" role="alert">
              {error}
            </p>
          )}
          <div className="dialog__actions">
            <button type="button" className="btn btn--quiet" onClick={close}>
              Keep current time
            </button>
            <button type="submit" className="btn btn--primary" disabled={busy}>
              {busy ? "Moving…" : "Move meeting"}
            </button>
          </div>
        </form>
      )}
    </Dialog>
  );
}
