"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client";
import { useApp } from "./AppContext";
import { Dialog } from "./Dialog";

type Mail = {
  id: string;
  threadId: string;
  from: string;
  subject: string;
  date: string;
  summary: string;
  unread: boolean;
  bucket: "needs_you" | "can_wait" | "fyi";
  suggestedReply?: string;
};

const GROUPS: { key: Mail["bucket"]; title: string; empty: string }[] = [
  { key: "needs_you", title: "Needs you", empty: "No one's waiting on you. Nice." },
  { key: "can_wait", title: "Can wait", empty: "Nothing here." },
  { key: "fyi", title: "For your info", empty: "No updates or receipts." },
];

export function InboxView() {
  const { notify } = useApp();
  const [items, setItems] = useState<Mail[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [drafting, setDrafting] = useState<Mail | null>(null);
  const [reply, setReply] = useState("");
  const [saving, setSaving] = useState(false);
  const [replyError, setReplyError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await api<{ items: Mail[] }>("/api/inbox");
      setItems(d.items);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't read your inbox.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function archive(m: Mail) {
    setItems((list) => list?.filter((x) => x.id !== m.id) ?? null);
    try {
      await api("/api/inbox/archive", { method: "POST", body: JSON.stringify({ messageId: m.id }) });
      notify({ tone: "jade", title: "Archived", body: m.subject });
    } catch (e) {
      notify({ tone: "rose", title: "Couldn't archive", body: e instanceof Error ? e.message : undefined });
      load();
    }
  }

  async function saveDraft() {
    if (!drafting) return;
    if (!reply.trim()) return setReplyError("Write a reply first.");
    setSaving(true);
    try {
      await api("/api/inbox/draft", { method: "POST", body: JSON.stringify({ messageId: drafting.id, body: reply }) });
      notify({ tone: "jade", title: "Saved to Gmail drafts", body: `Reply to ${drafting.from}` });
      setDrafting(null);
    } catch (e) {
      setReplyError(e instanceof Error ? e.message : "Couldn't save the draft.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="page">
      <div className="page__head">
        <div>
          <h1 className="page__title">Inbox</h1>
          <p className="page__lede">The last week of mail, sorted by Jun. Nothing gets sent without you.</p>
        </div>
        <button type="button" className="btn" onClick={load} disabled={loading}>
          {loading ? "Sorting…" : "Sort again"}
        </button>
      </div>

      {error && (
        <div className="notice notice--rose" role="alert">
          <p>{error}</p>
        </div>
      )}
      {items === null && !error && <p className="muted">Reading your inbox…</p>}

      {items &&
        GROUPS.map((g) => {
          const list = items.filter((m) => m.bucket === g.key);
          return (
            <section key={g.key} className="mail-group" data-bucket={g.key} aria-labelledby={`g-${g.key}`}>
              <h2 id={`g-${g.key}`} className="section-title">
                {g.title} <span className="count">{list.length}</span>
              </h2>
              {list.length === 0 ? (
                <p className="muted">{g.empty}</p>
              ) : (
                <ul className="mail">
                  {list.map((m) => (
                    <li key={m.id} className="mail__item" data-unread={m.unread || undefined}>
                      <div className="mail__text">
                        <p className="mail__from">{m.from}</p>
                        <p className="mail__subject">{m.subject}</p>
                        <p className="mail__summary">{m.summary}</p>
                      </div>
                      <div className="mail__actions">
                        {g.key !== "fyi" && (
                          <button
                            type="button"
                            className={`btn btn--small${g.key === "needs_you" ? " btn--primary" : ""}`}
                            onClick={() => {
                              setDrafting(m);
                              setReply(m.suggestedReply ?? "");
                              setReplyError(null);
                            }}
                          >
                            Draft reply
                          </button>
                        )}
                        <button type="button" className="btn btn--small" onClick={() => archive(m)}>
                          Archive
                        </button>
                        <a
                          className="btn btn--small btn--quiet"
                          href={`https://mail.google.com/mail/u/0/#inbox/${m.threadId}`}
                          target="_blank"
                          rel="noreferrer"
                        >
                          Open in Gmail
                        </a>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          );
        })}

      <Dialog open={Boolean(drafting)} onClose={() => setDrafting(null)} title={drafting ? `Reply to ${drafting.from}` : "Reply"} closeOnBackdrop={false} wide>
        {drafting && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              saveDraft();
            }}
          >
            <p className="dialog__body muted">Re: {drafting.subject}</p>
            <label className="field">
              <span>Your reply</span>
              <textarea
                className="input input--area"
                rows={8}
                value={reply}
                onChange={(e) => {
                  setReply(e.target.value);
                  setReplyError(null);
                }}
                autoFocus
                aria-describedby={replyError ? "reply-error" : undefined}
              />
            </label>
            {replyError && (
              <p id="reply-error" className="form-error" role="alert">
                {replyError}
              </p>
            )}
            <div className="dialog__actions">
              <button type="button" className="btn btn--quiet" onClick={() => setDrafting(null)}>
                Cancel
              </button>
              <button type="submit" className="btn btn--primary" disabled={saving}>
                {saving ? "Saving…" : "Save to drafts"}
              </button>
            </div>
          </form>
        )}
      </Dialog>
    </div>
  );
}
